package com.ftn.android.reimagined_tribble.activities;

import android.support.v7.app.AppCompatActivity;

import com.ftn.android.reimagined_tribble.R;

import org.androidannotations.annotations.EActivity;

/**
 * Created by ftn/tim
 */
@EActivity(R.layout.activity_about)
public class AboutActivity extends AppCompatActivity {

}

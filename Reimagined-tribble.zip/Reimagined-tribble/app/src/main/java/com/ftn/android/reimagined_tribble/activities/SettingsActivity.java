package com.ftn.android.reimagined_tribble.activities;

import com.ftn.android.reimagined_tribble.R;

import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.PreferenceScreen;

/**
 * Created by szberko
 */

@PreferenceScreen(R.xml.preferences)
@EActivity
public class SettingsActivity extends AppCompatPreferenceActivity {

}
